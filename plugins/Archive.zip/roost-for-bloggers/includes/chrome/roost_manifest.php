{"gcm_user_visible_only":true,"gcm_sender_id":<?php echo wp_json_encode( $gcm_token ); ?>}
