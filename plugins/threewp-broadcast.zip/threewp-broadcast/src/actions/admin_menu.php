<?php

namespace threewp_broadcast\actions;

class admin_menu
	extends action
{
}
