<?php

namespace threewp_broadcast\actions;

class broadcasting_started
	extends action
{
	/**
		@brief		The broadcasting data.
		@since		20131005
	**/
	public $broadcasting_data;
}
