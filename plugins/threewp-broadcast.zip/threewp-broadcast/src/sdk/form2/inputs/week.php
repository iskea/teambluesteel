<?php

namespace plainview\sdk_broadcast\form2\inputs;

/**
	@brief		Input for week.
	@author		Edward Plainview <edward@plainview.se>
	@copyright	GPL v3
	@version	20130524
**/
class week
	extends date
{
	public $type = 'week';
}

