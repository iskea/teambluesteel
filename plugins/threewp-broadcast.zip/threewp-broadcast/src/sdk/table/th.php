<?php

namespace plainview\sdk_broadcast\table;

/**
	@brief		Cell of type TH.
	@since		20130430
**/
class th
	extends cell
{
	public $tag = 'th';
}
