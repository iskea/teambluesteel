<?php

namespace plainview\sdk_broadcast\table;

/**
	@brief		Foot section of table.
	@since		20130430
	@version	20130430
**/
class foot
	extends section
{
	public $tag = 'tfoot';
}
